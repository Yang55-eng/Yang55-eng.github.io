# -*- coding: utf-8 -*-
"""
hnau-physio-report / scripts/build_report.py
--------------------------------------------
把「内容 JSON」渲染成符合华中农业大学动物生理学实验报告模板的 .docx。

核心保证（全部来自已验证样例的实测值）：
  页面    : A4, 上下 2.0cm / 左右 2.5cm
  题目    : 黑体 14pt(四号) 加粗 居中
  实验时间: 黑体 12pt(小四) 居中
  姓名班级: 楷体 12pt 居中
  中文摘要/Abstract 标签: 黑体 12pt 加粗
  摘要正文: 宋体12 + TNR12, 首行缩进2字
  一级标题: 黑体 14pt 加粗, 左对齐
  二级标题: 黑体 12pt 加粗, 左对齐
  正文    : 宋体12 + TNR12, 首行缩进2字
  行距    : 固定 26 磅（图片段除外 → 单倍行距防裁剪）
  表格    : 三线表, 表头宋体12加粗居中, 数据宋体12居中, 单倍行距
  图      : 居中, 单倍行距防裁剪
  图题/表题: 黑体12加粗居中
  图注/表注: 宋体12
  参考文献: 上角标超链接([n]) + 条目书签(refN)

【WPS 字体兼容关键】所有 <w:rFonts> 一律写 ascii/hAnsi/eastAsia/cs 四槽。
含中文的 run 必须带 w:hint="eastAsia"，WPS 才把中文判给 eastAsia 槽；
缺少该属性时 WPS 按 ascii 槽（Times New Roman）解析整段，
中文回退为默认字体，表现为「正文字体/实验时间未识别成功」。
纯西文 run（如英文摘要）不写 hint，以保证 Times New Roman 生效。

【图片防裁剪关键】任何含 <w:drawing> 的段落必须 lineRule="auto" line="240"(单倍)，
不能用固定行距，否则图片会被裁掉。

用法：
    python build_report.py content.json -o 报告.docx
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import zipfile
from xml.sax.saxutils import escape

# ============================================================================
# 字体与尺寸常量（内部名，WPS 必需）
# ============================================================================
FONT_HAN_TITLE = "SimHei"      # 黑体
FONT_HAN_KAI = "KaiTi"         # 楷体
FONT_HAN_SONG = "SimSun"       # 宋体
FONT_LATIN = "Times New Roman"

SZ_TITLE = 14        # 四号
SZ_H1 = 14           # 四号
SZ_SMALL4 = 12       # 小四
SZ_NOTE = 10.5       # 五号（表注可略小，保持12更符合模板，故用12）
LINE_FIXED = 520     # 固定行距 26pt = 520 twips
LINE_AUTO = 240      # 单倍行距

# 表格占位符词表：出现任一即视为「数据尚未填写」，未放行时阻断生成
PLACEHOLDERS = ("待填", "待补充", "TBD", "tbd", "TODO", "N/A")

# ---------------------------------------------------------------------------
# 防编造闸门（用户硬要求：内容不胡编乱造）
# ---------------------------------------------------------------------------
# 只捕获「数值 + 物理单位」形式的读数断言，如 "10.0 mV"、"3.2 m/s"、"8 ms"。
# 型号(BL-420F)、步骤序号(3次)、分数(2/3)、年份(18世纪)、数量(7根) 均不匹配，
# 因此不会误报。任何匹配到的读数都必须在 evidence.claims 中申报来源。
# 注意：前瞻排除集用 [A-Za-z0-9_.\-] 而非 \w —— Python 的 \w 会匹配中文，
# 导致 "约-8.5 mV"、"约0.00 mV" 被误判为「前面是字母」而漏报。
NUMBER_RE = re.compile(
    r"(?<![A-Za-z0-9_.\-])(-?\d+(?:\.\d+)?)"
    r"\s*"
    r"(mV|μV|uV|kV|m/s|cm/s|km/h|ms|μs|us|ns|min|h|Hz|kHz|MHz|"
    r"mmol/L|mol/L|mg/mL|μg/mL|ug/mL|g/L|mg|μg|ug|mL|μL|uL|"
    r"cm|mm|μm|um|nm|℃|°C|%)"
)

# 允许的来源类型。**不包含** "assumed"/"estimated"/"unknown"：
# 那类来源即「编造」，脚本一律阻断。
ALLOWED_CLAIM_SOURCES = ("user", "ppt", "literature", "derived")
SOURCE_HINT = ("user=用户提供的原始数据；ppt=课件原文；"
               "literature=已发表文献；derived=由以上数值计算得出")


def iter_texts(content: dict):
    """产出 (位置描述, 文本)，覆盖所有会被渲染进 docx 的文字。"""
    title = content.get("title", "")
    if title:
        yield ("题目", title)
    for key, label in (("abstract_zh", "中文摘要"), ("abstract_en", "英文摘要")):
        ab = content.get(key) or {}
        if ab.get("text"):
            yield (label, ab["text"])
        if ab.get("keywords"):
            yield (label + "关键词", ab["keywords"])
    for sec in content.get("sections", []):
        h1 = sec.get("h1", "")
        for blk in sec.get("blocks", []):
            t = blk.get("type")
            if t in ("p", "h2", "raw_p") and blk.get("text"):
                yield ("%s" % h1, blk["text"])
            elif t == "table":
                if blk.get("caption"):
                    yield ("%s 表题" % h1, blk["caption"])
                for row in blk.get("rows", []):
                    for cell in row:
                        yield ("%s 表格" % h1, str(cell))
                if blk.get("note"):
                    yield ("%s 表注" % h1, blk["note"])
            elif t == "image":
                if blk.get("caption"):
                    yield ("%s 图题" % h1, blk["caption"])
                if blk.get("note"):
                    yield ("%s 图注" % h1, blk["note"])
    # refs 不扫描：文献页码/年份属正常内容，非实验读数


def find_unclaimed_numbers(content: dict) -> list:
    """找出「已写进报告、但未申报来源」的数值读数。

    返回 [(位置, 读数), ...]，去重。
    设计意图：任何实验读数都必须能在 evidence.claims 里指出来源，
    否则说明它是凭空写上去的 —— 直接阻断，逼出「先问用户」这一步。
    """
    claims = []
    for c in (content.get("evidence") or {}).get("claims", []) or []:
        v = str((c or {}).get("value", "")).strip()
        if v:
            claims.append(v)

    hits, seen = [], set()
    for loc, txt in iter_texts(content):
        for m in NUMBER_RE.finditer(str(txt)):
            whole = m.group(0).strip()
            if any(whole in c or c in whole for c in claims):
                continue
            key = (loc, whole)
            if key in seen:
                continue
            seen.add(key)
            hits.append((loc, whole))
    return hits


def find_bad_claim_sources(content: dict) -> list:
    """找出来源类型不合法的申报项（如 source 写成 estimated/assumed/unknown）。"""
    bad = []
    for c in (content.get("evidence") or {}).get("claims", []) or []:
        c = c or {}
        src = str(c.get("source", "")).strip().lower()
        if src not in ALLOWED_CLAIM_SOURCES:
            bad.append((str(c.get("value", "")), src or "(缺失)"))
    return bad

# 页面：A4 21x29.7cm，上下2.0 左右2.5
PG_W = 11906         # twips
PG_H = 16838
MG_T = 1134          # 2.0cm
MG_B = 1134
MG_L = 1417          # 2.5cm
MG_R = 1417


def _rpr(han: str, size_pt: float, bold: bool = False, sup: bool = False,
         hint_east_asia: bool = False) -> str:
    """生成 runPr。四槽齐全。

    hint_east_asia=True 时额外写 w:hint="eastAsia"：
    WPS 需要该属性才能把中文判给 eastAsia 槽。缺少它时 WPS 会把整段
    按 ascii 槽（Times New Roman）解析，导致中文回退为默认字体，
    表现为用户看到的「正文字体/实验时间未识别成功」。

    纯西文 run（如英文摘要）不写 hint，以保证 Times New Roman 正常生效。
    """
    sz = int(round(size_pt * 2))
    hint = ' w:hint="eastAsia"' if hint_east_asia else ""
    parts = [
        '<w:rFonts w:ascii="%s" w:hAnsi="%s" w:eastAsia="%s" w:cs="%s"%s />'
        % (FONT_LATIN, FONT_LATIN, han, FONT_LATIN, hint),
        '<w:sz w:val="%d" />' % sz,
        '<w:szCs w:val="%d" />' % sz,
    ]
    if bold:
        parts.append("<w:b />")
        parts.append("<w:bCs />")
    if sup:
        parts.append('<w:vertAlign w:val="superscript" />')
    return "<w:rPr>" + "".join(parts) + "</w:rPr>"


def _has_cjk(text: str) -> bool:
    """判断字符串是否含中日韩表意文字或中文标点（用于决定是否写 hint）。"""
    for ch in text:
        o = ord(ch)
        if 0x4E00 <= o <= 0x9FFF:      # CJK 统一表意文字
            return True
        if 0x3000 <= o <= 0x303F:      # CJK 标点
            return True
        if 0xFF00 <= o <= 0xFFEF:      # 全角字符
            return True
    return False


def _run(text: str, han: str, size_pt: float, bold: bool = False, sup: bool = False) -> str:
    if text == "":
        return ""
    # 含中文的 run 必须带 hint，否则 WPS 从 ascii 槽取字体 → 中文回退
    return '<w:r>%s<w:t xml:space="preserve">%s</w:t></w:r>' % (
        _rpr(han, size_pt, bold, sup, hint_east_asia=_has_cjk(text)),
        escape(text),
    )


def _para(
    runs_xml: str,
    *,
    align: str = "left",
    line: int = LINE_FIXED,
    line_rule: str = "exact",
    first_line_chars: int = 0,
    before: int = 0,
    after: int = 0,
) -> str:
    """生成段落。first_line_chars=200 表示首行缩进2字。"""
    ppr = []
    if before or after:
        ppr.append('<w:spacing w:before="%d" w:after="%d" />' % (before, after))
    ppr.append('<w:spacing w:line="%d" w:lineRule="%s" />' % (line, line_rule))
    if first_line_chars:
        ppr.append('<w:ind w:firstLineChars="%d" />' % first_line_chars)
    if align and align != "left":
        ppr.append('<w:jc w:val="%s" />' % align)
    return "<w:p><w:pPr>%s</w:pPr>%s</w:p>" % ("".join(ppr), runs_xml)


def para_text(text: str, han: str = FONT_HAN_SONG, size_pt: float = SZ_SMALL4,
              bold: bool = False, **kw) -> str:
    return _para(_run(text, han, size_pt, bold), **kw)


# ============================================================================
# 参考文献：正文 [n] → 上角标超链接；条目 → 书签
# ============================================================================
def runs_with_citations(text: str, han: str, size_pt: float) -> str:
    """
    把含 [n] 的文本切成 runs，引用部分套 hyperlink + 上角标。
    返回 runs_xml（不含 <w:p> 外壳）。
    """
    out = []
    pos = 0
    for m in re.finditer(r"\[(\d+)\]", text):
        n = m.group(1)
        if m.start() > pos:
            out.append(_run(text[pos:m.start()], han, size_pt))
        out.append(
            '<w:hyperlink w:anchor="ref%s" w:history="1">%s</w:hyperlink>'
            % (n, _run("[%s]" % n, han, size_pt, sup=True))
        )
        pos = m.end()
    if pos < len(text):
        out.append(_run(text[pos:], han, size_pt))
    return "".join(out)


def para_body(text: str, han: str = FONT_HAN_SONG, size_pt: float = SZ_SMALL4,
              first_line: bool = True, **kw) -> str:
    """正文段落，自动处理 [n] 引用上角标。"""
    kw.setdefault("first_line_chars", 200 if first_line else 0)
    return _para(runs_with_citations(text, han, size_pt), **kw)


def para_reference(text: str, idx: int, bm_id: int) -> str:
    """参考文献条目：加书签 ref{idx}。"""
    runs = _run(text, FONT_HAN_SONG, SZ_SMALL4)
    return (
        '<w:p><w:pPr><w:spacing w:line="%d" w:lineRule="exact" /></w:pPr>'
        '<w:bookmarkStart w:id="%d" w:name="ref%d" />%s<w:bookmarkEnd w:id="%d" />'
        "</w:p>" % (LINE_FIXED, bm_id, idx, runs, bm_id)
    )


# ============================================================================
# 三线表
# ============================================================================
THICK = "single;12;000000"   # 顶/底粗线
THIN = "single;6;000000"     # 表头下细线

REL_NS = (
    'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
    'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
    'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
    'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"'
)


def build_table(header: list, rows: list, widths: list | None = None) -> str:
    """三线表：全边框清除 → 顶线粗 → 表头行下细线 → 底线粗。"""
    ncol = len(header)
    if widths is None:
        total = 9638  # 版心宽度 twips (21-2.5-2.5=16cm ≈ 9072，保守取 9600 内)
        w = int(total / ncol)
        widths = [w] * ncol

    def grid():
        return "".join('<w:gridCol w:w="%d" />' % w for w in widths)

    def cell(text, w, *, bold=False, top=None, bottom=None):
        bd = ['<w:tcBorders>']
        bd.append('<w:top w:val="%s" w:sz="0" w:space="0" w:color="auto" />'
                  % ("none" if top is None else "single"))
        if top:
            bd[-1] = '<w:top w:val="single" w:sz="%d" w:space="0" w:color="000000" />' % (
                12 if top == "thick" else 6
            )
        bd.append('<w:bottom w:val="none" w:sz="0" w:space="0" w:color="auto" />')
        if bottom:
            bd[-1] = '<w:bottom w:val="single" w:sz="%d" w:space="0" w:color="000000" />' % (
                12 if bottom == "thick" else 6
            )
        bd.append('<w:left w:val="none" w:sz="0" w:space="0" w:color="auto" />')
        bd.append('<w:right w:val="none" w:sz="0" w:space="0" w:color="auto" />')
        bd.append("</w:tcBorders>")
        rpr = _rpr(FONT_HAN_SONG, SZ_SMALL4, bold, hint_east_asia=_has_cjk(str(text)))
        return (
            '<w:tc><w:tcPr><w:tcW w:w="%d" w:type="dxa" />%s'
            '<w:vAlign w:val="center" /></w:tcPr>'
            '<w:p><w:pPr><w:spacing w:line="240" w:lineRule="auto" />'
            '<w:jc w:val="center" /></w:pPr>'
            '<w:r>%s<w:t xml:space="preserve">%s</w:t></w:r></w:p></w:tc>'
            % (w, "".join(bd), rpr, escape(str(text)))
        )

    xml = ['<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid" />'
           '<w:tblW w:w="0" w:type="auto" />'
           '<w:jc w:val="center" />'
           '<w:tblBorders>'
           '<w:top w:val="none" w:sz="0" w:space="0" w:color="auto" />'
           '<w:left w:val="none" w:sz="0" w:space="0" w:color="auto" />'
           '<w:bottom w:val="none" w:sz="0" w:space="0" w:color="auto" />'
           '<w:right w:val="none" w:sz="0" w:space="0" w:color="auto" />'
           '<w:insideH w:val="none" w:sz="0" w:space="0" w:color="auto" />'
           '<w:insideV w:val="none" w:sz="0" w:space="0" w:color="auto" />'
           '</w:tblBorders>'
           '<w:tblLayout w:type="fixed" /></w:tblPr>'
           "<w:tblGrid>%s</w:tblGrid>" % grid()]

    # 表头行
    xml.append('<w:tr><w:trPr><w:cantSplit /></w:trPr>')
    for i, h in enumerate(header):
        xml.append(cell(h, widths[i], bold=True, top="thick", bottom="thin"))
    xml.append("</w:tr>")

    # 数据行
    for ri, row in enumerate(rows):
        last = ri == len(rows) - 1
        xml.append('<w:tr><w:trPr><w:cantSplit /></w:trPr>')
        for i in range(ncol):
            v = row[i] if i < len(row) else ""
            xml.append(cell(v, widths[i], bottom="thick" if last else None))
        xml.append("</w:tr>")

    xml.append("</w:tbl>")
    # 表格后空段（防粘连）
    xml.append(para_text("", size_pt=6))
    return "".join(xml)


# ============================================================================
# 图片
# ============================================================================
def build_image(rid: str, cx_emu: int, cy_emu: int, idx: int, name: str) -> str:
    """
    生成图片段落。lineRule=auto 单倍行距，防固定行距裁剪。
    居中。
    """
    did = 1000 + idx
    return (
        "<w:p><w:pPr><w:spacing w:line=\"%d\" w:lineRule=\"auto\" />"
        '<w:jc w:val="center" /></w:pPr>'
        "<w:r><w:rPr>%s</w:rPr><w:drawing>"
        '<wp:inline distT="0" distB="0" distL="0" distR="0">'
        '<wp:extent cx="%d" cy="%d" />'
        '<wp:effectExtent l="0" t="0" r="0" b="0" />'
        '<wp:docPr id="%d" name="Picture %d" descr="%s" />'
        '<wp:cNvGraphicFramePr><a:graphicFrameLocks '
        'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" noChangeAspect="1" />'
        "</wp:cNvGraphicFramePr>"
        "<a:graphic><a:graphicData "
        'uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
        "<pic:pic>"
        '<pic:nvPicPr><pic:cNvPr id="%d" name="%s" /><pic:cNvPicPr /></pic:nvPicPr>'
        '<pic:blipFill><a:blip r:embed="%s" /><a:stretch><a:fillRect /></a:stretch></pic:blipFill>'
        "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\" /><a:ext cx=\"%d\" cy=\"%d\" /></a:xfrm>"
        '<a:prstGeom prst="rect"><a:avLst /></a:prstGeom></pic:spPr>'
        "</pic:pic></a:graphicData></a:graphic>"
        "</wp:inline></w:drawing></w:r></w:p>"
        % (
            LINE_AUTO,
            _rpr(FONT_HAN_SONG, SZ_SMALL4).replace("<w:rPr>", "").replace("</w:rPr>", ""),
            cx_emu,
            cy_emu,
            did,
            did,
            name,
            did,
            name,
            rid,
            cx_emu,
            cy_emu,
        )
    )


# ============================================================================
# 文档骨架
# ============================================================================
def document_xml(body: str) -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<w:document %s><w:body>%s'
        '<w:sectPr><w:pgSz w:w="%d" w:h="%d" />'
        '<w:pgMar w:top="%d" w:right="%d" w:bottom="%d" w:left="%d" '
        'w:header="851" w:footer="992" w:gutter="0" />'
        '<w:docGrid w:linePitch="312" /></w:sectPr>'
        "</w:body></w:document>" % (REL_NS, body, PG_W, PG_H, MG_T, MG_R, MG_B, MG_L)
    )


STYLES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:docDefaults><w:rPrDefault><w:rPr>
<w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="SimSun" w:cs="Times New Roman" />
<w:sz w:val="24" /><w:szCs w:val="24" />
</w:rPr></w:rPrDefault>
<w:pPrDefault><w:pPr><w:spacing w:line="520" w:lineRule="exact" /></w:pPr></w:pPrDefault>
</w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal">
<w:name w:val="Normal" /><w:qFormat />
</w:style>
<w:style w:type="table" w:styleId="TableGrid">
<w:name w:val="Table Grid" />
<w:tblPr>
<w:tblBorders>
<w:top w:val="none" w:sz="0" w:space="0" w:color="auto" />
<w:left w:val="none" w:sz="0" w:space="0" w:color="auto" />
<w:bottom w:val="none" w:sz="0" w:space="0" w:color="auto" />
<w:right w:val="none" w:sz="0" w:space="0" w:color="auto" />
<w:insideH w:val="none" w:sz="0" w:space="0" w:color="auto" />
<w:insideV w:val="none" w:sz="0" w:space="0" w:color="auto" />
</w:tblBorders>
</w:tblPr>
</w:style>
</w:styles>"""

CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml" />
<Default Extension="xml" ContentType="application/xml" />
<Default Extension="png" ContentType="image/png" />
<Default Extension="jpg" ContentType="image/jpeg" />
<Default Extension="jpeg" ContentType="image/jpeg" />
<Default Extension="gif" ContentType="image/gif" />
<Default Extension="bmp" ContentType="image/bmp" />
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml" />
<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml" />
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml" />
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml" />
</Types>"""

ROOT_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml" />
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml" />
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml" />
</Relationships>"""

DOC_RELS_TMPL = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml" />
%s</Relationships>"""

APP_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">
<Application>Microsoft Office Word</Application>
<AppVersion>16.0000</AppVersion>
</Properties>"""


def core_xml(title: str, author: str) -> str:
    from xml.sax.saxutils import escape as esc
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<cp:coreProperties '
        'xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:dcterms="http://purl.org/dc/terms/" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        "<dc:title>%s</dc:title><dc:creator>%s</dc:creator>"
        "<cp:lastModifiedBy>%s</cp:lastModifiedBy>"
        "</cp:coreProperties>" % (esc(title), esc(author), esc(author))
    )


def with_note_prefix(note: str) -> str:
    """为表注/图注补齐"注："前缀，已带前缀则不重复添加（幂等）。

    避免 JSON 里已经写了"注：xxx"时渲染成"注：注：xxx"。
    """
    s = (note or "").strip()
    if not s:
        return s
    for pre in ("注：", "注:", "注 "):
        if s.startswith(pre):
            return "注：" + s[len(pre):].lstrip()
    return "注：" + s


def image_size_emu(path: str, max_w_cm: float = 14.5, max_h_cm: float = 9.0):
    """按原始像素比例计算显示尺寸（EMU），限制在版心内。"""
    w_px = h_px = None
    try:
        from PIL import Image
        with Image.open(path) as im:
            w_px, h_px = im.size
    except Exception:
        pass
    if not w_px or not h_px:
        # 兜底：默认 14cm 宽 4:3
        return int(max_w_cm * 360000), int(max_w_cm * 0.75 * 360000)

    dpi = 96.0
    w_cm = w_px / dpi * 2.54
    h_cm = h_px / dpi * 2.54
    scale = min(max_w_cm / w_cm, max_h_cm / h_cm, 1.0)
    w_cm *= scale
    h_cm *= scale
    return int(w_cm * 360000), int(h_cm * 360000)


def pack_docx(out_path: str, body: str, images: list, title: str, author: str):
    """
    images: [(rId, 本地路径), ...] 顺序即 rId 编号（rId100 起，避开 rId1=styles）
    """
    rels = []
    media_parts = {}
    for rid, src in images:
        ext = os.path.splitext(src)[1].lower() or ".png"
        media_name = "media/%s%s" % (rid, ext)
        rels.append(
            '<Relationship Id="%s" Type="http://schemas.openxmlformats.org/'
            'officeDocument/2006/relationships/image" Target="%s" />'
            % (rid, media_name)
        )
        with open(src, "rb") as f:
            media_parts["word/" + media_name] = f.read()

    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", CONTENT_TYPES)
        z.writestr("_rels/.rels", ROOT_RELS)
        z.writestr("word/document.xml", document_xml(body))
        z.writestr("word/styles.xml", STYLES_XML)
        z.writestr("word/_rels/document.xml.rels", DOC_RELS_TMPL % "\n".join(rels))
        z.writestr("docProps/app.xml", APP_XML)
        z.writestr("docProps/core.xml", core_xml(title, author))
        for name, data in media_parts.items():
            z.writestr(name, data)


# ============================================================================
# 内容 JSON → body
# ============================================================================
def render(content: dict) -> tuple[str, list]:
    """返回 (body_xml, images_list)。images 为 [(rid, src_path), ...]"""
    imgs: list = []
    b: list = []

    meta = content.get("meta", {})
    title = content.get("title", "").strip()
    date = meta.get("date", "").strip()
    who = meta.get("line", "").strip() or "姓名：%s      班级：%s      电话：%s" % (
        meta.get("name", ""),
        meta.get("class", ""),
        meta.get("phone", ""),
    )

    # 封面
    b.append(para_text("题目：" + title if title else "", FONT_HAN_TITLE, SZ_TITLE,
                       bold=True, align="center"))
    # 模板实测：实验时间行(黑体小四加粗)、姓名班级电话行(楷体小四加粗)均需加粗
    b.append(para_text("实验时间：" + date, FONT_HAN_TITLE, SZ_SMALL4,
                       bold=True, align="center"))
    b.append(para_text(who, FONT_HAN_KAI, SZ_SMALL4, bold=True, align="center"))
    b.append(para_text("", size_pt=SZ_SMALL4))

    # 中文摘要
    ab = content.get("abstract_zh", {})
    if ab:
        b.append(para_text("中文摘要：", FONT_HAN_TITLE, SZ_SMALL4, bold=True))
        b.append(para_body(ab.get("text", "")))
        if ab.get("keywords"):
            b.append(para_text("关键词：" + ab["keywords"], FONT_HAN_SONG, SZ_SMALL4))
        b.append(para_text("", size_pt=SZ_SMALL4))

    # Abstract
    en = content.get("abstract_en", {})
    if en:
        b.append(para_text("Abstract:", FONT_HAN_TITLE, SZ_SMALL4, bold=True))
        b.append(para_body(en.get("text", "")))
        if en.get("keywords"):
            b.append(para_text("Key words: " + en["keywords"], FONT_HAN_SONG, SZ_SMALL4))
        b.append(para_text("", size_pt=SZ_SMALL4))

    # 正文
    b.append(para_text("正  文", FONT_HAN_TITLE, SZ_TITLE, bold=True, align="center"))

    for sec in content.get("sections", []):
        h1 = sec.get("h1", "").strip()
        if h1:
            b.append(para_text(h1, FONT_HAN_TITLE, SZ_H1, bold=True))

        for blk in sec.get("blocks", []):
            t = blk.get("type")

            if t == "h2":
                b.append(para_text(blk["text"], FONT_HAN_TITLE, SZ_SMALL4, bold=True))

            elif t == "p":
                b.append(para_body(blk["text"]))

            elif t == "table":
                if blk.get("caption"):
                    b.append(para_text(blk["caption"], FONT_HAN_TITLE, SZ_SMALL4,
                                       bold=True, align="center"))
                b.append(build_table(blk["header"], blk["rows"], blk.get("widths")))
                if blk.get("note"):
                    b.append(para_text(with_note_prefix(blk["note"]),
                                       FONT_HAN_SONG, SZ_SMALL4))

            elif t == "image":
                # 校验 src：为空或文件不存在时给出可读错误，避免底层 open('') 报
                # FileNotFoundError: [Errno 2] No such file or directory: ''
                src = (blk.get("src") or "").strip()
                if not src:
                    raise ValueError(
                        "image 块的 src 为空。若该图暂时没有图片文件，请改用 "
                        "{\"type\":\"p\"} 段落写图题与图注，不要写 image 块。"
                    )
                if not os.path.isfile(src):
                    raise ValueError("image 块的 src 文件不存在: %s" % src)
                rid = "rId%d" % (100 + len(imgs))
                cx, cy = image_size_emu(src)
                b.append(build_image(rid, cx, cy, len(imgs) + 1, os.path.basename(src)))
                imgs.append((rid, src))
                if blk.get("caption"):
                    b.append(para_text(blk["caption"], FONT_HAN_TITLE, SZ_SMALL4,
                                       bold=True, align="center"))
                if blk.get("note"):
                    b.append(para_text(with_note_prefix(blk["note"]),
                                       FONT_HAN_SONG, SZ_SMALL4))

            elif t == "refs":
                for i, r in enumerate(blk["items"], start=1):
                    b.append(para_reference(r, i, 900 + i - 1))

            elif t == "raw_p":
                b.append(para_text(blk["text"], FONT_HAN_SONG, SZ_SMALL4))

    return "".join(b), imgs


def find_placeholder_cells(content: dict) -> list:
    """扫描所有表格单元格，找出仍是占位符的项。

    返回 [(表题, 行号, 列号, 单元格文本), ...]。
    占位符判定：文本等于/包含 PLACEHOLDER 词，或为空。
    用于在未显式放行时阻断生成，逼出「先问用户」这一步。
    """
    hits = []
    for sec in content.get("sections", []):
        for blk in sec.get("blocks", []):
            if blk.get("type") != "table":
                continue
            cap = blk.get("caption", "(无表题)")
            for ri, row in enumerate(blk.get("rows", []), start=1):
                for ci, cell in enumerate(row, start=1):
                    s = str(cell).strip()
                    if (not s) or any(p in s for p in PLACEHOLDERS):
                        hits.append((cap, ri, ci, s or "(空)"))
    return hits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("content_json")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument(
        "--allow-blank",
        action="store_true",
        help="允许表格中保留'待填'占位符。仅在已用弹窗询问过用户、"
             "且用户明确选择'稍后再填'时才可加此参数。",
    )
    ap.add_argument(
        "--allow-unclaimed",
        action="store_true",
        help="允许报告中出现未申报来源的数值读数。仅在用户明确要求复用"
             "有据可查的数据（如同一实验的往届报告）时才可加此参数。",
    )
    args = ap.parse_args()

    with open(args.content_json, encoding="utf-8-sig") as f:
        content = json.load(f)

    # 闸门 1：数值读数必须申报来源（防编造）
    bad_src = find_bad_claim_sources(content)
    if bad_src:
        msg = [
            "检测到 %d 处数值的「来源类型」不合法，已阻断生成。" % len(bad_src),
            "允许的来源类型：%s" % SOURCE_HINT,
            "不允许 assumed / estimated / unknown 等 —— 那属于编造。",
            "",
        ]
        for val, src in bad_src:
            msg.append("  · 数值 %s 的来源写作 %s" % (val, src))
        raise SystemExit("\n".join(msg))

    unclaimed = find_unclaimed_numbers(content)
    if unclaimed and not args.allow_unclaimed:
        msg = [
            "检测到 %d 处实验读数未申报来源，已阻断生成。" % len(unclaimed),
            "报告中出现的每个读数都必须能在 evidence.claims 里指出出处：",
            "  %s" % SOURCE_HINT,
            "",
        ]
        for loc, val in unclaimed:
            msg.append("  · [%s] %s" % (loc, val))
        msg.append("")
        msg.append("处理方式二选一：")
        msg.append("  (1) 先向用户索取这些数据；若用户暂无数据，改为'待填'占位；")
        msg.append("  (2) 若数据确实有据（课件原文/文献/用户提供），"
                   "在 content.json 的 evidence.claims 中逐条申报来源；")
        msg.append("  (3) 仅当用户明确要求复用已知来源数据时，加 --allow-unclaimed。")
        raise SystemExit("\n".join(msg))

    # 闸门 2：有占位符却未显式放行 → 必须先问用户
    blanks = find_placeholder_cells(content)
    if blanks and not args.allow_blank:
        msg = [
            "检测到 %d 处数据尚未填写，已阻断生成。" % len(blanks),
            "请先向用户确认这些数值：",
        ]
        for cap, ri, ci, txt in blanks:
            msg.append("  · %s 第%d行第%d列 = %s" % (cap, ri, ci, txt))
        msg.append("")
        msg.append("若用户明确选择「稍后再填」，加 --allow-blank 重新运行。")
        raise SystemExit("\n".join(msg))

    if blanks:
        print("[warn] 保留 %d 处'待填'占位（已获用户确认）" % len(blanks))

    body, imgs = render(content)
    meta = content.get("meta", {})
    pack_docx(
        args.out,
        body,
        imgs,
        content.get("title", "实验报告"),
        meta.get("name", ""),
    )

    print("[build] -> %s (%d bytes)" % (args.out, os.path.getsize(args.out)))
    n_refs = 0
    for sec in content.get("sections", []):
        for blk in sec.get("blocks", []):
            if blk.get("type") == "refs":
                n_refs += len(blk.get("items", []))
    n_cite = len(re.findall(r"\[\d+\]",
                            " ".join(blk.get("text", "") for sec in content.get("sections", [])
                                     for blk in sec.get("blocks", []))))
    print("        图片 %d 张, 参考文献 %d 条, 正文引用标记 %d 处" % (len(imgs), n_refs, n_cite))
    n_claims = len((content.get("evidence") or {}).get("claims", []) or [])
    print("        数值来源申报 %d 条" % n_claims)


if __name__ == "__main__":
    main()
