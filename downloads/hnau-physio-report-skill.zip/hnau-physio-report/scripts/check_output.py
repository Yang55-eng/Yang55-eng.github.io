# -*- coding: utf-8 -*-
"""
hnau-physio-report / scripts/check_output.py
--------------------------------------------
交付前自检：确认生成的 .docx 符合课程模板的全部硬性要求。

检查项（对应 SKILL.md 的自检清单）：
  1. 页面尺寸与页边距（上下2.0 / 左右2.5）
  2. 字体槽：含中文的 run 必须带 w:hint="eastAsia"（WPS 识别中文的必要条件），
     且 ascii/hAnsi/eastAsia/cs 四槽齐全；纯西文 run 不应带 hint
  3. 字体内部名：不得出现 宋体/黑体/楷体 等中文别名
  4. 参考文献：书签 refN 数量与正文最大引用编号一致
  5. 上角标：正文 [n] 为 superscript 且包在 hyperlink 内
  6. 图片：存在且所在段落为 lineRule=auto（防裁剪）
  7. 表格：三线表（存在顶/底粗线，无 insideH/insideV/左右边框）
  8. 内容完整性：含 AI 使用声明、中英摘要、七个章节
退出码：0 = 全部通过；1 = 有 FAIL

用法：
    python check_output.py "<报告.docx>" [--json out.json]
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import zipfile

# 中文别名 → 内部名（出现别名即 FAIL）
FONT_ALIAS_BAD = ["宋体", "黑体", "楷体", "仿宋", "微软雅黑", "等线"]

REQUIRED_SECTIONS = ["前言", "材料与方法", "结果", "讨论", "结论", "致谢", "参考文献"]


def _load(path):
    z = zipfile.ZipFile(path)
    parts = {}
    for n in z.namelist():
        if n.endswith(".xml") or n.endswith(".rels"):
            parts[n] = z.read(n).decode("utf-8", "ignore")
    names = z.namelist()
    z.close()
    return parts, names


def check(path: str) -> dict:
    results = []

    def rec(level, item, detail=""):
        results.append({"level": level, "item": item, "detail": detail})

    if not os.path.exists(path):
        return {"ok": False, "results": [{"level": "FAIL", "item": "文件存在", "detail": path}]}

    parts, names = _load(path)
    doc = parts.get("word/document.xml", "")
    styles = parts.get("word/styles.xml", "")
    rels = parts.get("word/_rels/document.xml.rels", "")

    # ---- 1. 页面 ----
    m = re.search(r'<w:pgSz w:w="(\d+)" w:h="(\d+)"', doc)
    if m:
        w, h = int(m.group(1)), int(m.group(2))
        rec("PASS" if (w, h) == (11906, 16838) else "WARN", "页面 A4",
            "%.1f x %.1f cm" % (w / 567.0, h / 567.0))
    else:
        rec("FAIL", "页面 A4", "未找到 pgSz")

    m = re.search(r'<w:pgMar([^/]*)/>', doc)
    if m:
        a = dict(re.findall(r'w:(\w+)="(-?\d+)"', m.group(1)))
        t = int(a.get("top", 0)) / 567.0
        b = int(a.get("bottom", 0)) / 567.0
        l = int(a.get("left", 0)) / 567.0
        r = int(a.get("right", 0)) / 567.0
        ok = abs(t - 2.0) < .05 and abs(b - 2.0) < .05 and abs(l - 2.5) < .05 and abs(r - 2.5) < .05
        rec("PASS" if ok else "FAIL", "页边距 上下2.0/左右2.5",
            "上%.2f 下%.2f 左%.2f 右%.2f" % (t, b, l, r))
    else:
        rec("FAIL", "页边距", "未找到 pgMar")

    # ---- 2. 字体槽 ----
    # WPS 判定中文字体的依据是 w:hint="eastAsia"：缺它时 WPS 按 ascii 槽
    # （Times New Roman）解析整段，中文回退默认字体 → 用户看到"字体未识别"。
    # 故检查规则为：含中文的 run 必须带 hint；纯西文 run 不应带 hint。
    all_xml = doc + styles
    cjk_no_hint = 0
    latin_with_hint = 0
    for m in re.finditer(r"<w:r>(.*?)</w:r>", doc, re.S):
        run = m.group(1)
        txt = "".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", run, re.S))
        if not txt.strip():
            continue
        has_cjk = any(0x4E00 <= ord(c) <= 0x9FFF or 0x3000 <= ord(c) <= 0x303F
                      or 0xFF00 <= ord(c) <= 0xFFEF for c in txt)
        has_hint = 'w:hint="eastAsia"' in run
        if has_cjk and not has_hint:
            cjk_no_hint += 1
        elif (not has_cjk) and has_hint:
            latin_with_hint += 1
    cnt_hint = len(re.findall(r'hint="eastAsia"', doc))
    rec("PASS" if cjk_no_hint == 0 else "FAIL",
        "中文 run 均带 w:hint（WPS 识别中文的必要条件）",
        "%d 个中文 run 带 hint，缺 hint 的 %d 个" % (cnt_hint, cjk_no_hint))
    rec("PASS" if latin_with_hint == 0 else "WARN",
        "西文 run 未误加 hint（保证 Times New Roman 生效）",
        "误加 %d 个" % latin_with_hint)

    rfonts = re.findall(r"<w:rFonts([^/]*)/>", all_xml)
    four = [x for x in rfonts
            if re.search(r'w:ascii="', x) and re.search(r'w:hAnsi="', x)
            and re.search(r'w:eastAsia="', x) and re.search(r'w:cs="', x)]
    rec("PASS" if len(four) == len(rfonts) and rfonts else "FAIL", "四槽齐全",
        "%d/%d 个 rFonts" % (len(four), len(rfonts)))

    # ---- 3. 字体内部名 ----
    bad = [a for a in FONT_ALIAS_BAD if re.search(r'w:(?:ascii|hAnsi|eastAsia|cs)="%s"' % re.escape(a), all_xml)]
    rec("PASS" if not bad else "FAIL", "字体用内部名（非中文别名）",
        "发现别名：%s" % "、".join(bad) if bad else "未发现别名")

    # ---- 4. 书签 vs 引用编号 ----
    bms = sorted(int(x) for x in re.findall(r'<w:bookmarkStart[^>]*w:name="ref(\d+)"', doc))
    cited = sorted(set(int(x) for x in re.findall(r'<w:hyperlink w:anchor="ref(\d+)"', doc)))
    if bms:
        ok = bms == list(range(1, max(bms) + 1))
        rec("PASS" if ok else "FAIL", "书签连续 ref1..refN",
            "书签 %s" % bms)
        miss = [c for c in cited if c not in bms]
        rec("PASS" if not miss else "FAIL", "引用均有对应书签",
            "缺失 %s" % miss if miss else "%d 个引用全部可跳转" % len(cited))
    else:
        rec("FAIL", "参考文献书签", "未找到任何 refN 书签")

    # ---- 5. 上角标 ----
    n_hl = len(re.findall(r"<w:hyperlink ", doc))
    # 上角标 run 应位于 hyperlink 内部
    sup_in_hl = 0
    for hm in re.finditer(r"<w:hyperlink [^>]*>.*?</w:hyperlink>", doc, re.S):
        if "superscript" in hm.group(0):
            sup_in_hl += 1
    rec("PASS" if sup_in_hl == n_hl and n_hl > 0 else "FAIL", "引用上角标+超链接",
        "%d/%d 个超链接含上角标" % (sup_in_hl, n_hl))

    # ---- 6. 图片防裁剪 ----
    n_pic = len(re.findall(r"<w:drawing>", doc))
    media = [n for n in names if n.startswith("word/media/")]
    rid_embed = set(re.findall(r'r:embed="(rId\d+)"', doc))
    rid_rel = dict(re.findall(r'Id="(rId\d+)"[^>]*Target="([^"]*)"', rels))
    broken = [r for r in rid_embed if r not in rid_rel or "media/" not in rid_rel.get(r, "")]
    rec("PASS" if not broken else "FAIL", "图片 rels 指向正确",
        "异常 %s" % broken if broken else "%d 个 rId 均指向 media/" % len(rid_embed))
    rec("PASS" if len(media) >= n_pic and n_pic > 0 else
        ("WARN" if n_pic == 0 else "FAIL"), "图片文件已打包",
        "包内 %d 个 media / 文档 %d 个 drawing" % (len(media), n_pic))

    # 图片段落必须 lineRule=auto
    bad_img_para = 0
    for pm in re.finditer(r"<w:p[ >].*?</w:p>", doc, re.S):
        para = pm.group(0)
        if "<w:drawing>" in para:
            if 'w:lineRule="auto"' not in para:
                bad_img_para += 1
    rec("PASS" if bad_img_para == 0 else "FAIL", "图片段落单倍行距（防裁剪）",
        "%d 个图片段落用了固定行距" % bad_img_para if bad_img_para else "全部为 auto")

    # ---- 7. 三线表 ----
    n_tbl = len(re.findall(r"<w:tbl>", doc))
    tbl_xml = "".join(re.findall(r"<w:tbl>.*?</w:tbl>", doc, re.S))
    has_thick = 'w:sz="12"' in tbl_xml
    has_inside_border = bool(re.search(r'<w:inside[HV] w:val="(?!none)', tbl_xml))
    has_side_border = bool(re.search(r'<w:(?:left|right) w:val="(?!none)', tbl_xml))
    rec("PASS" if has_thick else "FAIL", "三线表粗线存在", "sz=12 顶/底线")
    rec("PASS" if not has_inside_border else "FAIL", "三线表无内部框线", "")
    rec("PASS" if not has_side_border else "FAIL", "三线表无左右框线", "")
    rec("INFO", "表格数量", "%d 个" % n_tbl)

    # ---- 8. 内容完整性 ----
    text = "".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", doc, re.S))
    rec("PASS" if "AI使用声明" in text or "AI 使用声明" in text else "FAIL",
        "含 AI 使用声明", "")
    rec("PASS" if "中文摘要" in text else "FAIL", "含中文摘要", "")
    rec("PASS" if re.search(r"Abstract", text, re.I) else "FAIL", "含英文摘要", "")
    missing = [s for s in REQUIRED_SECTIONS if s not in text]
    rec("PASS" if not missing else "WARN", "七章节齐全",
        "缺 %s" % "、".join(missing) if missing else "全部存在")
    rec("PASS" if re.search(r"\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日", text) else "FAIL",
        "实验时间为具体日期", "")
    rec("PASS" if "第03周" not in text and "学时" not in text else "FAIL",
        "无课表话术（第X周/学时）", "")
    rec("INFO", "字数", "%d" % len(text))

    fails = sum(1 for r in results if r["level"] == "FAIL")
    return {"ok": fails == 0, "fails": fails,
            "warns": sum(1 for r in results if r["level"] == "WARN"),
            "results": results}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("docx")
    ap.add_argument("--json", default="")
    args = ap.parse_args()

    r = check(args.docx)

    icon = {"PASS": "[OK]  ", "FAIL": "[FAIL]", "WARN": "[WARN]", "INFO": "[--]  "}
    print("=" * 66)
    print("自检: %s" % os.path.basename(args.docx))
    print("=" * 66)
    for it in r["results"]:
        print("%s %-30s %s" % (icon.get(it["level"], "?"), it["item"], it["detail"]))
    print("-" * 66)
    print("结果: %s  (FAIL=%d, WARN=%d)" % ("通过" if r["ok"] else "未通过",
                                          r["fails"], r["warns"]))

    if args.json:
        with open(args.json, "w", encoding="utf-8", newline="\n") as f:
            json.dump(r, f, ensure_ascii=False, indent=1)

    return 0 if r["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
