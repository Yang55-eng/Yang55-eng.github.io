# -*- coding: utf-8 -*-
"""
hnau-physio-report / scripts/check_render.py
--------------------------------------------
在「渲染层」验证 WPS 是否真的识别到了字体、字号。

为什么需要它：只读 docx 的 XML 只能证明「我写了什么」，不能证明
「WPS 认出了什么」。本脚本用 WPS 自己的引擎把 docx 转成 PDF，
再从 PDF 里读出**实际嵌入的字体名与字号** —— 这才是用户眼里看到的。

判据：
  · 含中文的 span，字体必须落在中文字体集合内(SimSun/SimHei/KaiTi…)；
    若落到 TimesNewRoman* ，就是用户所说的「字体未识别成功」。
  · 西文/数字 span 应为 TimesNewRoman*（若被中文字体接管则说明 hint 写多了）。
  · 关键要素逐项核对：题目/实验时间→黑体，姓名行→楷体，正文→宋体，英文摘要→TNR。
  · 字号应落在 {12pt, 14pt}（PDF 有轻微缩放，容差 ±0.8）。

用法：
    python check_render.py "<报告.docx>" [--keep-pdf] [--json out.json]

退出码：0 全部 PASS；1 存在 FAIL。
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

# 中文字体集合（渲染后 PDF 内嵌名）
CJK_FONTS = {"SimSun", "SimHei", "KaiTi", "NSimSun", "FangSong",
             "MicrosoftYaHei", "MicrosoftYaHeiUI", "DengXian", "STSong"}
LATIN_FONTS = {"TimesNewRomanPSMT", "TimesNewRomanPS-BoldMT", "TimesNewRomanMT"}

# 关键要素 → (文本特征正则, 期望字体集合, 说明)
KEY_RULES = [
    (r"^题目[：:]", {"SimHei"}, "题目行"),
    (r"^实验时间[：:]", {"SimHei"}, "实验时间行"),
    (r"^(姓名|班级|电话)[：:]", {"KaiTi"}, "姓名班级电话行"),
    (r"^中文摘要[：:]", {"SimHei"}, "中文摘要标签"),
    (r"^Abstract", {"TimesNewRomanPS-BoldMT", "TimesNewRomanPSMT"}, "Abstract 标签"),
    (r"^(关键词|Key words)", {"SimSun", "TimesNewRomanPSMT"}, "关键词行"),
    (r"^正", {"SimHei"}, "正文分节标题"),
]


def _has_cjk(text: str) -> bool:
    for ch in text:
        o = ord(ch)
        if 0x4E00 <= o <= 0x9FFF or 0x3000 <= o <= 0x303F or 0xFF00 <= o <= 0xFFEF:
            return True
    return False


def _norm_font(name: str) -> str:
    """去掉 PDF 子集前缀（如 ABCDEE+SimSun）与尾随空格。"""
    n = (name or "").split("+")[-1].strip()
    return n.replace(" ", "")


def wps_export_pdf(docx: str, pdf: str, timeout: int = 180) -> tuple[bool, str]:
    """调 wps_export_pdf.ps1，用 WPS 引擎把 docx 转 PDF。"""
    ps1 = os.path.join(os.path.dirname(os.path.abspath(__file__)), "wps_export_pdf.ps1")
    if not os.path.isfile(ps1):
        return False, "缺少 wps_export_pdf.ps1"
    exe = shutil.which("powershell") or shutil.which("powershell.exe")
    if not exe:
        return False, "未找到 powershell"
    try:
        r = subprocess.run(
            [exe, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", ps1,
             "-Docx", docx, "-Pdf", pdf],
            capture_output=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return False, "WPS 转换超时（可能被弹窗阻塞）"
    out = (r.stdout or b"").decode("utf-8", "replace") + (r.stderr or b"").decode("utf-8", "replace")
    return (os.path.isfile(pdf) and os.path.getsize(pdf) > 0), out.strip()


def read_spans(pdf: str) -> list:
    import pymupdf
    doc = pymupdf.open(pdf)
    spans = []
    for pi, page in enumerate(doc):
        d = page.get_text("dict")
        for b in d.get("blocks", []):
            if b.get("type") != 0:
                continue
            for line in b.get("lines", []):
                for s in line.get("spans", []):
                    t = s.get("text", "")
                    if not t.strip():
                        continue
                    spans.append({
                        "page": pi + 1,
                        "text": t,
                        "font": _norm_font(s.get("font", "")),
                        "size": round(float(s.get("size", 0)), 1),
                        "bold": bool(s.get("flags", 0) & 16),
                    })
    doc.close()
    return spans


def analyze(spans: list) -> tuple[list, int]:
    """返回 (结果列表, fail 数)。每条 = (级别, 项目, 详情)。"""
    res = []
    fails = 0

    def rec(level, item, detail):
        nonlocal fails
        if level == "FAIL":
            fails += 1
        res.append((level, item, detail))

    if not spans:
        rec("FAIL", "PDF 文本提取", "未取到任何文本 span")
        return res, fails

    fonts = sorted({s["font"] for s in spans})
    rec("INFO", "渲染字体种类", "%d 种：%s" % (len(fonts), ", ".join(fonts)))

    cjk_spans = [s for s in spans if _has_cjk(s["text"])]
    latin_spans = [s for s in spans if not _has_cjk(s["text"])]

    # 1) 中文 span 必须用中文字体
    bad_cjk = [s for s in cjk_spans if s["font"] not in CJK_FONTS]
    rec("PASS" if not bad_cjk else "FAIL",
        "中文使用中文字体",
        "%d 个中文 span，异常 %d 处%s" % (
            len(cjk_spans), len(bad_cjk),
            "" if not bad_cjk else "：" + "; ".join(
                "%s→%s" % (s["text"][:12], s["font"]) for s in bad_cjk[:5])))

    # 2) 西文/数字 span 不应被中文字体接管
    bad_latin = [s for s in latin_spans if s["font"] in CJK_FONTS and len(s["text"].strip()) > 1]
    rec("PASS" if not bad_latin else "WARN",
        "西文使用 Times New Roman",
        "%d 个西文 span，被中文字体接管 %d 处%s" % (
            len(latin_spans), len(bad_latin),
            "" if not bad_latin else "：" + "; ".join(
                "'%s'→%s" % (s["text"][:14], s["font"]) for s in bad_latin[:5])))

    # 3) 是否真的嵌入了中文字体
    rec("PASS" if (set(fonts) & CJK_FONTS) else "FAIL",
        "检测到中文字体嵌入",
        "命中：%s" % (", ".join(sorted(set(fonts) & CJK_FONTS)) or "无"))

    # 4) 关键要素逐项核对
    for pat, expect, label in KEY_RULES:
        m = [s for s in spans if re.search(pat, s["text"])]
        if not m:
            rec("INFO", "要素·%s" % label, "文档中未出现，跳过")
            continue
        good = [s for s in m if s["font"] in expect]
        rec("PASS" if good else "FAIL",
            "要素·%s" % label,
            "字体 %s（期望 %s），共 %d 处" % (
                ", ".join(sorted({s["font"] for s in m})),
                "/".join(sorted(expect)), len(m)))

    # 5) 字号合规（上角标 [n] 会按 ~0.65 倍缩放，属正常，排除）
    sup_re = re.compile(r"^\[\d+\]$")
    sizes = sorted({s["size"] for s in spans})
    off = [s for s in spans
           if not sup_re.match(s["text"].strip())
           and not any(abs(s["size"] - e) <= 0.8 for e in (12.0, 14.0))]
    detail = "实际字号 %s；越界 %d 处" % (", ".join(str(x) for x in sizes), len(off))
    if off:
        detail += "：" + "; ".join(
            "%.1fpt'%s'" % (s["size"], s["text"][:10]) for s in off[:6])
    rec("PASS" if not off else "WARN", "字号∈{12,14}pt", detail)

    return res, fails


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("docx")
    ap.add_argument("--keep-pdf", action="store_true", help="保留导出的 PDF 供人工查看")
    ap.add_argument("--json", dest="json_out", help="把结果写成 JSON")
    args = ap.parse_args()

    docx = os.path.abspath(args.docx)
    if not os.path.isfile(docx):
        print("[FAIL] 文件不存在：%s" % docx)
        return 2

    tmp = tempfile.mkdtemp(prefix="hnau_render_")
    # 用 ASCII 路径规避中文路径在 COM/子进程间的编码问题
    ascii_docx = os.path.join(tmp, "report.docx")
    ascii_pdf = os.path.join(tmp, "report.pdf")
    shutil.copy(docx, ascii_docx)

    print("=== WPS 渲染层字体验证 ===")
    print("源文件：%s" % docx)
    ok, info = wps_export_pdf(ascii_docx, ascii_pdf)
    if not ok:
        print("[FAIL] WPS 导出 PDF 失败：%s" % info)
        print("       请确认本机已安装 WPS（KWps.Application COM 可用）。")
        shutil.rmtree(tmp, ignore_errors=True)
        return 1

    spans = read_spans(ascii_pdf)
    res, fails = analyze(spans)

    for level, item, detail in res:
        print("[%s] %-18s %s" % (level, item, detail))
    print("---")
    print("结果：%s（共 %d 项检查，FAIL %d）" % ("通过" if fails == 0 else "未通过", len(res), fails))

    if args.keep_pdf:
        dst = os.path.splitext(docx)[0] + "_wps预览.pdf"
        shutil.copy(ascii_pdf, dst)
        print("PDF 预览：%s" % dst)

    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as f:
            json.dump({"spans": spans,
                       "results": [{"level": l, "item": i, "detail": d} for l, i, d in res],
                       "fails": fails}, f, ensure_ascii=False, indent=1)

    shutil.rmtree(tmp, ignore_errors=True)
    return 0 if fails == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
