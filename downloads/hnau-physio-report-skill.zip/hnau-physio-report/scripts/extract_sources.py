# -*- coding: utf-8 -*-
"""
hnau-physio-report / scripts/extract_sources.py
-----------------------------------------------
一次性把「PPT + 数据文件 + 模板」抽取成紧凑的 JSON，供 AI 阅读。

设计目标：**最大程度节省 token**
- PPT 只抽取文字 + 备注 + 图片数量，丢弃全部版式/XML 噪声
- .doc/.docx 数据文件抽取正文表格与图片
- 模板抽取段落格式规范（字体/字号/对齐/行距/缩进），一次性固化
- 输出单个 JSON，AI 只需读这一个文件即可掌握全部素材

用法：
    python extract_sources.py --ppt a.pptx b.pptx --data 04.doc --out sources.json
    python extract_sources.py --ppt *.pptx --out sources.json
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import zipfile


# ----------------------------------------------------------------------------
# PPT 抽取
# ----------------------------------------------------------------------------
def _slide_sort_key(name: str) -> int:
    m = re.search(r"slide(\d+)\.xml$", name)
    return int(m.group(1)) if m else 0


def extract_pptx(path: str) -> dict:
    """抽取 PPT 每页文字 + 备注文字 + 图片清单。"""
    if not os.path.exists(path):
        return {"file": path, "error": "文件不存在"}

    z = zipfile.ZipFile(path)
    names = z.namelist()

    slides = sorted(
        [n for n in names if re.match(r"ppt/slides/slide\d+\.xml$", n)],
        key=_slide_sort_key,
    )
    # 备注：ppt/notesSlides/notesSlideN.xml 与 slide 顺序对应（N 不保证与 slide 编号一致，
    # 用 rels 精确映射更稳，但实践中两者通常一一对应；此处保守做法是逐页读 rels）
    notes_map = {}
    for s in slides:
        sid = _slide_sort_key(s)
        rels = "ppt/slides/_rels/slide%d.xml.rels" % sid
        if rels in names:
            rx = z.read(rels).decode("utf-8", "ignore")
            m = re.search(r'Target="\.\./(notesSlides/notesSlide\d+\.xml)"', rx)
            if m:
                notes_map[sid] = "ppt/" + m.group(1)

    # 图片：按 slide 的 rels 找 media
    media_by_slide = {}
    for s in slides:
        sid = _slide_sort_key(s)
        rels = "ppt/slides/_rels/slide%d.xml.rels" % sid
        imgs = []
        if rels in names:
            rx = z.read(rels).decode("utf-8", "ignore")
            for mm in re.finditer(r'Target="\.\./(media/[^"]+)"', rx):
                imgs.append(mm.group(1))
        media_by_slide[sid] = imgs

    pages = []
    for s in slides:
        sid = _slide_sort_key(s)
        x = z.read(s).decode("utf-8", "ignore")
        texts = [t for t in re.findall(r"<a:t>(.*?)</a:t>", x, re.S) if t.strip()]
        # a:t 内部 XML 实体还原
        texts = [
            t.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            for t in texts
        ]
        note = ""
        np_ = notes_map.get(sid)
        if np_ and np_ in names:
            nx = z.read(np_).decode("utf-8", "ignore")
            nt = [t for t in re.findall(r"<a:t>(.*?)</a:t>", nx, re.S) if t.strip()]
            # 过滤掉纯页码
            nt = [t for t in nt if not re.fullmatch(r"\d{1,3}", t.strip())]
            note = " ".join(nt)
        pages.append(
            {
                "slide": sid,
                "text": texts,
                "note": note,
                "images": media_by_slide.get(sid, []),
            }
        )

    # 提取内嵌图片到 sidecar 目录（供后续插图复用）
    z.close()
    return {
        "file": os.path.basename(path),
        "path": os.path.abspath(path),
        "total_slides": len(pages),
        "pages": pages,
    }


# ----------------------------------------------------------------------------
# 数据文件（.docx / .doc）抽取
# ----------------------------------------------------------------------------
def extract_docx(path: str) -> dict:
    """抽取 docx 正文段落文本 + 表格 + 图片清单。"""
    if not os.path.exists(path):
        return {"file": path, "error": "文件不存在"}

    z = zipfile.ZipFile(path)
    names = z.namelist()
    if "word/document.xml" not in names:
        z.close()
        return {"file": os.path.basename(path), "error": "非 docx 结构（可能是 .doc 老格式，需先转换）"}

    doc = z.read("word/document.xml").decode("utf-8", "ignore")

    paragraphs = []
    for pm in re.finditer(r"<w:p[ >].*?</w:p>", doc, re.S):
        para = pm.group(0)
        txt = "".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", para, re.S))
        txt = (
            txt.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        )
        if txt.strip():
            paragraphs.append(txt)

    # 表格：按行抽取单元格文本
    tables = []
    for tm in re.finditer(r"<w:tbl>.*?</w:tbl>", doc, re.S):
        tbl = tm.group(0)
        rows = []
        for rm in re.finditer(r"<w:tr[ >].*?</w:tr>", tbl, re.S):
            cells = []
            for cm in re.finditer(r"<w:tc>.*?</w:tc>", rm.group(0), re.S):
                ct = "".join(
                    re.findall(r"<w:t[^>]*>(.*?)</w:t>", cm.group(0), re.S)
                )
                cells.append(
                    ct.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                )
            rows.append(cells)
        if rows:
            tables.append(rows)

    media = [n for n in names if n.startswith("word/media/")]
    z.close()

    return {
        "file": os.path.basename(path),
        "path": os.path.abspath(path),
        "paragraphs": paragraphs,
        "tables": tables,
        "images": media,
        "image_count": len(media),
    }


# ----------------------------------------------------------------------------
# 模板格式抽取（docx）
# ----------------------------------------------------------------------------
def extract_template(path: str) -> dict:
    """抽取模板/样例的段落格式规范 + 页面设置。"""
    if not os.path.exists(path):
        return {"file": path, "error": "文件不存在"}
    if path.lower().endswith(".doc") and not path.lower().endswith(".docx"):
        return {
            "file": os.path.basename(path),
            "error": ".doc 老格式：请先用 Word 另存为 .docx（SaveAs 格式码 16）后再抽取",
        }

    z = zipfile.ZipFile(path)
    names = z.namelist()
    doc = z.read("word/document.xml").decode("utf-8", "ignore")

    # 页面设置
    sect = re.search(r"<w:sectPr[^>]*>.*?</w:sectPr>", doc, re.S)
    margin = {}
    if sect:
        pg = re.search(r'<w:pgMar([^/]*)/>', sect.group(0))
        if pg:
            attrs = dict(re.findall(r'w:(\w+)="(-?\d+)"', pg.group(1)))
            margin = {
                k: round(int(v) / 567.0, 2)  # twips -> cm
                for k, v in attrs.items()
                if k in ("top", "bottom", "left", "right")
            }

    # 逐段格式
    spec = []
    for pm in re.finditer(r"<w:p[ >].*?</w:p>", doc, re.S):
        para = pm.group(0)
        txt = "".join(re.findall(r"<w:t[^>]*>(.*?)</w:t>", para, re.S))
        rpr = re.search(r"<w:rPr>.*?</w:rPr>", para, re.S)
        rfonts = {}
        sz = None
        bold = False
        if rpr:
            rf = re.search(r"<w:rFonts([^/]*)/>", rpr.group(0))
            if rf:
                rfonts = dict(re.findall(r'w:(\w+)="([^"]*)"', rf.group(1)))
            szm = re.search(r'<w:sz w:val="(\d+)"', rpr.group(0))
            if szm:
                sz = int(szm.group(1)) / 2.0  # half-point -> pt
            bold = "<w:b />" in rpr.group(0) or "<w:b/>" in rpr.group(0)
        ppr = re.search(r"<w:pPr>.*?</w:pPr>", para, re.S)
        align = None
        line = None
        line_rule = None
        indent = None
        if ppr:
            am = re.search(r'<w:jc w:val="(\w+)"', ppr.group(0))
            if am:
                align = am.group(1)
            lm = re.search(r'<w:spacing([^/]*)/>', ppr.group(0))
            if lm:
                la = dict(re.findall(r'w:(\w+)="(-?\d+)"', lm.group(1)))
                if "line" in la:
                    line = int(la["line"]) / 20.0  # twips -> pt
                line_rule = la.get("lineRule")
            im = re.search(r'<w:ind([^/]*)/>', ppr.group(0))
            if im:
                indent = dict(re.findall(r'w:(\w+)="(-?\d+)"', im.group(1)))
        spec.append(
            {
                "text": txt[:40],
                "ascii": rfonts.get("ascii"),
                "eastAsia": rfonts.get("eastAsia"),
                "size_pt": sz,
                "bold": bold,
                "align": align,
                "line_pt": line,
                "lineRule": line_rule,
                "indent": indent,
            }
        )

    z.close()
    return {
        "file": os.path.basename(path),
        "path": os.path.abspath(path),
        "page_margin_cm": margin,
        "paragraph_spec": spec,
    }


# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ppt", nargs="*", default=[], help="PPT 文件（一个或多个）")
    ap.add_argument("--data", nargs="*", default=[], help="数据文件 .doc/.docx")
    ap.add_argument("--template", default="", help="模板/样例 docx")
    ap.add_argument("--out", default="sources.json", help="输出 JSON 路径")
    args = ap.parse_args()

    result = {"ppt": [], "data": [], "template": None}

    for p in args.ppt:
        if os.path.exists(p):
            result["ppt"].append(extract_pptx(p))
        else:
            result["ppt"].append({"file": p, "error": "文件不存在"})

    for d in args.data:
        if os.path.exists(d):
            result["data"].append(extract_docx(d))
        else:
            result["data"].append({"file": d, "error": "文件不存在"})

    if args.template:
        result["template"] = extract_template(args.template)

    with open(args.out, "w", encoding="utf-8", newline="\n") as f:
        json.dump(result, f, ensure_ascii=False, indent=1)

    # 控制台摘要（简短，省 token）
    print("[extract] -> %s" % args.out)
    for p in result["ppt"]:
        if "error" in p:
            print("  PPT %s: ERROR %s" % (p["file"], p["error"]))
        else:
            imgs = sum(len(x["images"]) for x in p["pages"])
            print("  PPT %s: %d 页, %d 张内嵌图" % (p["file"], p["total_slides"], imgs))
    for d in result["data"]:
        if "error" in d:
            print("  数据 %s: ERROR %s" % (d["file"], d["error"]))
        else:
            print(
                "  数据 %s: %d 段, %d 表, %d 图"
                % (d["file"], len(d["paragraphs"]), len(d["tables"]), d["image_count"])
            )
    if result["template"]:
        t = result["template"]
        if "error" in t:
            print("  模板 %s: ERROR %s" % (t["file"], t["error"]))
        else:
            print("  模板 %s: %d 段格式" % (t["file"], len(t["paragraph_spec"])))


if __name__ == "__main__":
    main()
