# -*- coding: utf-8 -*-
"""
hnau-physio-report / scripts/validate_input.py
----------------------------------------------
上传素材的「体检」：在动手写报告之前，先把用户给的东西核对一遍，
把「传错 PPT / 数据与实验对不上 / 缺信息」这几类问题明确抛给用户。

检查项：
  A. PPT 是否为「华中农业大学动物生理学实验」课件（关键词命中率）
  B. 有多个 PPT 时，是否为同一实验（避免把实验一的 PPT 配实验二的数据）
  C. 数据文件里的读数是否与实验类型自洽（量纲/量级/字段名）
  D. 元信息（时间/姓名/班级/电话）是否齐全
  E. 实验数据是否到位 —— 缺失时写进 questions，逼出「先问用户」这一步

用法：
    python validate_input.py --sources sources.json --meta meta.json
输出：JSON（写到 stdout 或 --out），含 ok / warnings / errors / questions
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

def load_json(path: str):
    """读 JSON，兼容 Windows 常见的 UTF-8 BOM（utf-8-sig）。"""
    with open(path, encoding="utf-8-sig") as f:
        return json.load(f)


def dump_json(obj, path: str):
    """写 JSON，统一无 BOM UTF-8，保证下游可读。"""
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)


# 生理学实验常见关键词（用于判断是不是本课程课件）
COURSE_KEYWORDS = [
    "蛙", "脊蛙", "蟾蜍", "牛蛙", "坐骨神经", "腓肠肌", "任氏液", "锌铜弓",
    "动作电位", "不应期", "反射", "反射弧", "脊髓", "刺激", "标本",
    "BL-420", "生物信号", "神经", "肌肉", "屏蔽盒", "电极",
]

# 各实验的「指纹」关键词 —— 用来判断 PPT 属于哪个实验
EXPERIMENT_FINGERPRINTS = {
    "sciatic_neuromuscular": {
        "name": "坐骨神经-腓肠肌标本制备 / 动作电位引导 / 不应期测定",
        "must": ["坐骨神经", "腓肠肌"],
        "any": ["动作电位", "不应期", "锌铜弓", "屏蔽盒", "BL-420", "传导速度"],
        "forbid": ["反射弧", "脊蛙", "搔扒"],
    },
    "spinal_reflex": {
        "name": "脊髓反射的基本特征和反射弧分析",
        "must": ["反射"],
        "any": ["反射弧", "脊蛙", "搔扒", "脊髓", "硫酸", "屈肌"],
        "forbid": ["腓肠肌标本制备"],
    },
}

# 数据字段 → 允许的实验类型
DATA_FIELD_HINTS = {
    "不应期": ["sciatic_neuromuscular"],
    "t1": ["sciatic_neuromuscular"],
    "t2": ["sciatic_neuromuscular"],
    "峰峰值": ["sciatic_neuromuscular"],
    "最大值": ["sciatic_neuromuscular"],
    "最小值": ["sciatic_neuromuscular"],
    "刺激强度": ["sciatic_neuromuscular", "spinal_reflex"],
    "反射时": ["spinal_reflex"],
    "阈值": ["spinal_reflex", "sciatic_neuromuscular"],
    "mV": ["sciatic_neuromuscular"],
    "ms": ["sciatic_neuromuscular", "spinal_reflex"],
}


def classify_ppt(pages: list) -> dict:
    """按指纹关键词判断 PPT 属于哪个实验。"""
    all_text = " ".join(
        " ".join(p.get("text", [])) + " " + p.get("note", "") for p in pages
    )
    scores = {}
    for key, fp in EXPERIMENT_FINGERPRINTS.items():
        s = 0
        for kw in fp["must"]:
            if kw in all_text:
                s += 3
        for kw in fp["any"]:
            if kw in all_text:
                s += 1
        for kw in fp["forbid"]:
            if kw in all_text:
                s -= 4
        scores[key] = s
    best = max(scores, key=scores.get) if scores else None
    return {
        "scores": scores,
        "best": best,
        "best_name": EXPERIMENT_FINGERPRINTS[best]["name"] if best else None,
        "keyword_hits": sum(1 for k in COURSE_KEYWORDS if k in all_text),
    }


def detect_data_fields(data_entries: list) -> set:
    """从数据文件正文里嗅探出现的字段名。"""
    fields = set()
    blob = []
    for d in data_entries:
        if "error" in d:
            continue
        blob.extend(d.get("paragraphs", []))
        for t in d.get("tables", []):
            for row in t:
                blob.extend([str(c) for c in row])
    text = " ".join(blob)
    for f in DATA_FIELD_HINTS:
        if f in text:
            fields.add(f)
    return fields, text


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sources", required=True, help="extract_sources.py 产出的 JSON")
    ap.add_argument("--meta", default="", help="元信息 JSON（date/name/class/phone）")
    ap.add_argument("--out", default="", help="输出 JSON 路径")
    args = ap.parse_args()

    with open(args.sources, encoding="utf-8-sig") as f:
        src = json.load(f)

    errors, warnings, questions = [], [], []

    # ---------- A / B. PPT 检查 ----------
    classified = []
    for i, p in enumerate(src.get("ppt", [])):
        if "error" in p:
            errors.append("PPT「%s」无法读取：%s" % (p["file"], p["error"]))
            continue
        c = classify_ppt(p.get("pages", []))
        classified.append((p["file"], c))
        if c["keyword_hits"] < 3:
            errors.append(
                "PPT「%s」看起来**不是本课程的生理学实验课件**"
                "（只命中 %d 个课程关键词）。请确认传的是华中农业大学动物生理学实验课件，"
                "而不是其他课程的 PPT。" % (p["file"], c["keyword_hits"])
            )
        elif c["best"] is None or c["scores"].get(c["best"], 0) <= 0:
            warnings.append(
                "PPT「%s」能确认是本课程课件，但无法判断属于哪个实验，"
                "请人工确认实验题目。" % p["file"]
            )

    # 多个 PPT 是否同一实验
    if len(classified) >= 2:
        bests = {c["best"] for _, c in classified if c["best"]}
        if len(bests) > 1:
            detail = "；".join("%s → %s" % (fn, c["best_name"]) for fn, c in classified)
            errors.append(
                "上传了**多个属于不同实验的 PPT**（%s）。"
                "一次应只上传同一个实验的 PPT（若该实验含多部分，请都上传完整的同一实验课件）。"
                % detail
            )

    # ---------- C. 数据与实验是否自洽 ----------
    fields, blob = detect_data_fields(src.get("data", []))
    for d in src.get("data", []):
        if "error" in d:
            warnings.append("数据文件「%s」未能抽取内容：%s" % (d["file"], d["error"]))

    ppt_exps = {c["best"] for _, c in classified if c["best"]}
    if fields and ppt_exps:
        mismatch = []
        for f in fields:
            allowed = set(DATA_FIELD_HINTS.get(f, []))
            if allowed and not (allowed & ppt_exps):
                mismatch.append(f)
        if len(mismatch) >= 2:
            errors.append(
                "**数据与 PPT 的实验类型明显对不上**：数据里出现字段 %s，"
                "但 PPT 判定为「%s」。请确认数据和 PPT 是不是同一个实验的。"
                % ("、".join(mismatch), "、".join(
                    EXPERIMENT_FINGERPRINTS[e]["name"] for e in ppt_exps))
            )

    # 数值量级合理性（动作电位幅度典型 0.1~50 mV；不应期间隔典型 0.1~20 ms）
    nums = [float(x) for x in re.findall(r"-?\d+\.?\d*", blob)]
    if nums:
        big = [n for n in nums if 100 < abs(n) < 100000]
        # 只提示，不阻断
        if not big:
            pass

    # ---------- D. 元信息 ----------
    meta = {}
    if args.meta and os.path.exists(args.meta):
        meta = load_json(args.meta)

    for key, label in [("date", "实验时间"), ("name", "姓名"),
                       ("class", "班级"), ("phone", "电话")]:
        v = str(meta.get(key, "")).strip()
        if not v:
            questions.append(label)
        elif key == "phone" and not re.fullmatch(r"1[3-9]\d{9}", v):
            warnings.append("电话号码「%s」格式不像 11 位手机号，请核对。" % v)
        elif key == "date" and not re.search(r"\d{4}\s*年", v):
            warnings.append("实验时间「%s」不是「X年X月X日」格式，请核对。" % v)

    # ---------- E. 实验数据是否到位（缺数据必须问用户，不许硬编） ----------
    data_entries = src.get("data", []) or []
    usable = [d for d in data_entries if "error" not in d]
    data_provided = bool(usable)
    if not data_entries:
        questions.append("实验原始数据（波形图截图 / 含读数的 .doc/.docx/.xlsx）")
        warnings.append(
            "**本次没有提供任何实验数据文件。** 报告中所有实测读数（如动作电位幅度、"
            "传导速度、不应期 t1/t2）都无据可依，只能留「待填」。"
            "动手写报告前必须先弹窗询问用户是否现在提供数据；"
            "只有用户明确选择「稍后再填」才可继续生成。**不得凭经验估算数值。**"
        )
    elif not usable:
        errors.append(
            "提供了 %d 个数据文件但**均无法读取**，请重新提供可读版本。"
            % len(data_entries)
        )

    result = {
        "ok": len(errors) == 0,
        "ppt_classification": [
            {"file": fn, **c} for fn, c in classified
        ],
        "data_fields": sorted(fields),
        "data_provided": data_provided,
        "errors": errors,
        "warnings": warnings,
        "questions": questions,
    }

    out = json.dumps(result, ensure_ascii=False, indent=1)
    if args.out:
        dump_json(result, args.out)
    print(out)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
