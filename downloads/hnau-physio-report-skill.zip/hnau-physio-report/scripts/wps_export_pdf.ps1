# wps_export_pdf.ps1
# Convert a .docx to PDF using the locally installed WPS via COM (KWps.Application).
# This provides render-layer evidence of which fonts WPS actually resolved.
# NOTE: keep this file ASCII-only -- Windows PowerShell 5.1 reads .ps1 as ANSI,
# so non-ASCII characters here would corrupt the script. Callers pass paths in.
param(
    [Parameter(Mandatory = $true)][string]$Docx,
    [Parameter(Mandatory = $true)][string]$Pdf
)
$ErrorActionPreference = "Stop"

if (-not (Test-Path $Docx)) { Write-Output "DOCX_NOT_FOUND"; exit 2 }
if (Test-Path $Pdf) { Remove-Item $Pdf -Force }

$app = $null
$doc = $null
try {
    $app = New-Object -ComObject KWps.Application
    $app.Visible = $false
    try { $app.DisplayAlerts = 0 } catch { }
    $doc = $app.Documents.Open($Docx)
    $doc.SaveAs($Pdf, 17)
    Write-Output "PDF_OK"
}
catch {
    Write-Output ("PDF_FAIL " + $_.Exception.Message)
    exit 3
}
finally {
    if ($doc -ne $null) { try { $doc.Close(0) } catch { } }
    if ($app -ne $null) { try { $app.Quit() } catch { } }
}
